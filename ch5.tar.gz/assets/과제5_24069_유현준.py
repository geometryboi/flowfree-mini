import pygame
import sys

pygame.init()

# ===== 설정 =====
CELL_SIZE = 60
FPS = 60

COLORS = {
    0: (30, 30, 30),
    1: (255, 0, 0),
    2: (255, 255, 0),
    3: (0, 0, 255),
    4: (0, 255, 0),
    5: (135, 206, 235),
    6: (255, 165, 0),
    7: (255, 105, 180),
    8: (128, 0, 128),
    9: (139, 69, 19),
    10: (255, 255, 255),
    11: (127, 127, 127),
}

# ===== 전체 스테이지 복구 =====
stages = [
    [
        [0,0,0,0,3],
        [0,2,4,0,2],
        [0,0,0,0,1],
        [0,0,4,0,0],
        [3,0,0,0,1],
    ],
    [
        [2, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 6, 1, 3, 0],
        [0, 0, 0, 0, 0, 0, 0],
        [6, 0, 0, 0, 4, 0, 0],
        [5, 0, 4, 0, 1, 0, 0],
        [0, 0, 0, 0, 3, 0, 0],
        [0, 0, 0, 5, 2, 0, 0],
    ],
    [
        [9, 0, 0, 0, 0, 0, 0, 0, 0],
        [7, 1, 5, 0, 2, 9, 3, 6, 0],
        [0, 0, 0, 0, 0, 8, 0, 0, 0],
        [0, 7, 1, 5, 0, 0, 0, 4, 0],
        [0, 0, 3, 2, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 8, 0, 0, 0, 0, 0, 0, 0],
        [0, 6, 0, 4, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0],
    ],
    [
        [0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 7, 1, 0, 6, 0, 0, 0, 0, 0, 0],
        [0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 8, 0, 0, 0, 2, 0],
        [0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 6, 0, 0, 0, 0, 0, 8, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 2, 4, 0],
        [0, 0, 0, 0, 0, 3, 0, 7, 1, 0, 0],
    ],
    [
        [0, 0, 0, 11,0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 7, 0, 8, 0, 1, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 10,0, 0, 0, 0, 4, 0, 2, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 5, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 11,3, 5, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 6, 0, 0, 3, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 7, 10,0, 0, 0, 6, 9, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 8, 9, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ],
]


class Grid:
    def __init__(self, stage):
        self.original = [row[:] for row in stage]
        self.board = [row[:] for row in stage]
        self.N = len(stage)
        self.paths = {}
        self.endpoints = {}
        self._init_endpoints()

    def _init_endpoints(self):
        for i in range(self.N):
            for j in range(self.N):
                if self.original[i][j] != 0:
                    c = self.original[i][j]
                    self.endpoints.setdefault(c, []).append((i, j))

    def reset_path(self, color):
        for (x, y) in self.paths.get(color, []):
            if self.original[x][y] == 0:
                self.board[x][y] = 0
        self.paths[color] = []

    def is_clear(self):
        for row in self.board:
            if 0 in row:
                return False

        for color in self.endpoints:
            if color not in self.paths:
                return False

            path = self.paths[color]
            ends = self.endpoints[color]

            if len(path) < 2:
                return False

            if not ((path[0] == ends[0] and path[-1] == ends[1]) or
                    (path[0] == ends[1] and path[-1] == ends[0])):
                return False

        return True


class Renderer:
    def __init__(self, screen, font):
        self.screen = screen
        self.font = font

    def cell_center(self, r, c):
        return (c*CELL_SIZE + CELL_SIZE//2, r*CELL_SIZE + CELL_SIZE//2)

    def draw(self, grid, show_popup):
        self.screen.fill((0,0,0))
        N = grid.N

        for color, path in grid.paths.items():
            for i in range(len(path)-1):
                pygame.draw.line(self.screen, COLORS[color],
                                 self.cell_center(*path[i]),
                                 self.cell_center(*path[i+1]),
                                 CELL_SIZE//2)

        for i in range(N):
            for j in range(N):
                if grid.board[i][j] != 0:
                    pygame.draw.circle(self.screen, COLORS[grid.board[i][j]],
                                       self.cell_center(i,j), CELL_SIZE//4)

        for i in range(N):
            for j in range(N):
                rect = pygame.Rect(j*CELL_SIZE, i*CELL_SIZE, CELL_SIZE, CELL_SIZE)
                pygame.draw.rect(self.screen, (200,200,200), rect, 1)

        for i in range(N):
            for j in range(N):
                if grid.original[i][j] != 0:
                    pygame.draw.circle(self.screen, COLORS[grid.original[i][j]],
                                       self.cell_center(i,j), CELL_SIZE//3)

        button_rect = None
        if show_popup:
            overlay = pygame.Surface(self.screen.get_size())
            overlay.set_alpha(180)
            overlay.fill((0,0,0))
            self.screen.blit(overlay, (0,0))

            text = self.font.render("Solved!", True, (255,255,255))
            self.screen.blit(text, (self.screen.get_width()//2 - text.get_width()//2, self.screen.get_height()//2 - 80))

            button_rect = pygame.Rect(self.screen.get_width()//2 - 100, self.screen.get_height()//2, 200, 60)
            pygame.draw.rect(self.screen, (200,200,200), button_rect)

            btn_text = self.font.render("Next", True, (0,0,0))
            self.screen.blit(btn_text, (button_rect.x + 50, button_rect.y + 10))

        pygame.display.flip()
        return button_rect


class Game:
    def __init__(self):
        self.stage_idx = 0
        self.screen = pygame.display.set_mode((800, 800))
        pygame.display.set_caption("Flow Free OOP")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont(None, 50)

        self.grid = Grid(stages[self.stage_idx])
        self.renderer = Renderer(self.screen, self.font)

        self.current_color = None
        self.show_popup = False

    def get_cell(self, pos):
        x, y = pos
        return y // CELL_SIZE, x // CELL_SIZE

    def is_adjacent(self, a, b):
        return abs(a[0]-b[0]) + abs(a[1]-b[1]) == 1

    def next_stage(self):
        self.stage_idx += 1
        if self.stage_idx >= len(stages):
            print("All Clear!")
            pygame.quit()
            sys.exit()
        self.grid = Grid(stages[self.stage_idx])
        self.show_popup = False
        size = self.grid.N * CELL_SIZE
        self.screen = pygame.display.set_mode((size, size))
        self.renderer.screen = self.screen

    def run(self):
        running = True
        while running:
            self.clock.tick(FPS)
            button_rect = self.renderer.draw(self.grid, self.show_popup)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if self.show_popup:
                        if button_rect and button_rect.collidepoint(pygame.mouse.get_pos()):
                            self.next_stage()
                        continue

                    r, c = self.get_cell(pygame.mouse.get_pos())
                    if 0 <= r < self.grid.N and 0 <= c < self.grid.N:
                        if self.grid.original[r][c] != 0:
                            color = self.grid.original[r][c]
                            self.grid.reset_path(color)
                            self.grid.paths[color] = [(r, c)]
                            self.current_color = color

                elif event.type == pygame.MOUSEBUTTONUP:
                    self.current_color = None

                elif event.type == pygame.MOUSEMOTION:
                    if self.current_color is None or self.show_popup:
                        continue

                    r, c = self.get_cell(pygame.mouse.get_pos())
                    if not (0 <= r < self.grid.N and 0 <= c < self.grid.N):
                        continue

                    path = self.grid.paths[self.current_color]
                    last = path[-1]

                    if not self.is_adjacent(last, (r, c)):
                        continue

                    if len(path) >= 2 and (r, c) == path[-2]:
                        self.grid.board[last[0]][last[1]] = 0
                        path.pop()
                        continue

                    if (r, c) in path:
                        continue

                    if self.grid.board[r][c] != 0 and self.grid.board[r][c] != self.current_color:
                        continue

                    self.grid.board[r][c] = self.current_color
                    path.append((r, c))

            if self.grid.is_clear() and not self.show_popup:
                self.show_popup = True

        pygame.quit()
        sys.exit()


if __name__ == "__main__":
    Game().run()
