import pygame, random, sys

pygame.init()

info = pygame.display.Info()
WIDTH, HEIGHT = info.current_w, info.current_h
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()

TILE = 32
GROUND_Y = TILE * 1
MAX_SPEED = 10
VISION_RADIUS = 3

COLORS = {
    "dirt": (100,70,40),
    "iron": (200,200,200),
    "copper": (200,100,50),
    "water": (50,150,255),
    "rock": (120,120,120),
    "grass": (80,200,80),
    "broken": (200,150,120),
    "player": (50,255,200)
}

# ===== 블록 =====
class Block:
    def __init__(self, x, y, unbreakable=False):
        self.x = x
        self.y = y
        self.unbreakable = unbreakable

        self.max_hp = 2 + y * 0.3
        self.hp = self.max_hp

        r = random.random()
        if r < 0.02 + y*0.0005:
            self.type = "iron"
        elif r < 0.03 + y*0.0005:
            self.type = "copper"
        elif r < 0.04 + y*0.0005:
            self.type = "water"
        else:
            self.type = "dirt"

    def damage(self):
        if self.unbreakable:
            return None
        self.hp -= 1
        if self.hp <= 0:
            return self.type
        return None

    def draw(self, cam_y):
        rect = pygame.Rect(self.x*TILE, self.y*TILE - cam_y, TILE, TILE)
        pygame.draw.rect(screen, COLORS[self.type], rect)

        if not self.unbreakable:
            ratio = self.hp / self.max_hp
            c = (30,30,30)

            if ratio < 0.7:
                pygame.draw.line(screen, c, rect.topleft, rect.bottomright, 2)
            if ratio < 0.4:
                pygame.draw.line(screen, c, rect.topright, rect.bottomleft, 2)
            if ratio < 0.15:
                pygame.draw.line(screen, c,
                    (rect.centerx, rect.top),
                    (rect.centerx, rect.bottom), 2)

# ===== 월드 =====
class World:
    def __init__(self):
        self.blocks = {}
        self.broken = {}
        self.seen = {}
        self.generate()

    def generate(self):
        W = WIDTH // TILE

        for y in range(200):
            for x in range(W):
                if y == 0: continue
                self.blocks[(x,y)] = Block(x,y)
                self.seen[(x,y)] = False

        for x in range(W):
            self.blocks[(x,1)] = Block(x,1, True)
            self.blocks[(x,1)].type = "grass"
            self.seen[(x,1)] = True

        mid = W // 2

        self.blocks[(mid,1)].unbreakable = False
        self.blocks[(mid+1,1)].unbreakable = False
        self.blocks[(mid,1)].type = "dirt"
        self.blocks[(mid+1,1)].type = "dirt"

        for x in range(W):
            if x == mid or x == mid + 1:
                continue
            self.blocks[(x,2)] = Block(x,2, True)
            self.blocks[(x,2)].type = "rock"
            self.seen[(x,2)] = True

        wall = 4
        for y in range(3, 200):
            for x in range(wall):
                if (x,y) in self.blocks:
                    b = self.blocks[(x,y)]
                    b.type = "rock"
                    b.unbreakable = True

            for x in range(W-wall, W):
                if (x,y) in self.blocks:
                    b = self.blocks[(x,y)]
                    b.type = "rock"
                    b.unbreakable = True

        for y in range(5, 200):
            l = random.randint(0,2)
            r = random.randint(0,2)

            for x in range(wall+l):
                if (x,y) in self.blocks:
                    b = self.blocks[(x,y)]
                    b.type = "rock"
                    b.unbreakable = True

            for x in range(W-wall-r, W):
                if (x,y) in self.blocks:
                    b = self.blocks[(x,y)]
                    b.type = "rock"
                    b.unbreakable = True

    def update_vision(self, player):
        px = int((player.x + player.w/2) // TILE)
        py = int((player.y + player.h/2) // TILE)

        for (x,y) in self.blocks:
            if y*TILE < GROUND_Y:
                self.seen[(x,y)] = True

        for dx in range(-VISION_RADIUS, VISION_RADIUS+1):
            for dy in range(-VISION_RADIUS, VISION_RADIUS+1):
                if dx*dx + dy*dy <= VISION_RADIUS*VISION_RADIUS:
                    pos = (px+dx, py+dy)
                    if pos in self.seen:
                        self.seen[pos] = True

    def get(self,x,y):
        return self.blocks.get((x,y))

    def remove(self,x,y):
        if (x,y) in self.blocks:
            del self.blocks[(x,y)]
            self.broken[(x,y)] = True

    def draw(self, cam_y):
        for (x,y) in self.broken:
            if not self.seen.get((x,y), False):
                continue
            rect = pygame.Rect(x*TILE, y*TILE - cam_y, TILE, TILE)
            pygame.draw.rect(screen, COLORS["broken"], rect)

        for (x,y), b in self.blocks.items():
            rect = pygame.Rect(x*TILE, y*TILE - cam_y, TILE, TILE)

            if not self.seen.get((x,y), False):
                pygame.draw.rect(screen, (0,0,0), rect)
            else:
                b.draw(cam_y)

# ===== 플레이어 =====
class Player:
    def __init__(self):
        self.w = 20
        self.h = 20

        self.x = WIDTH//2
        self.y = TILE - self.h - 2

        self.vx = 0
        self.vy = 0

        self.on_ground = False
        self.inv = {"iron":0,"copper":0,"water":0}

        self.last_hit_time = 0
        self.hit_cooldown = 200

    def collide(self, world):
        corners = [
            (self.x, self.y),
            (self.x+self.w, self.y),
            (self.x, self.y+self.h),
            (self.x+self.w, self.y+self.h)
        ]

        for cx, cy in corners:
            gx = int(cx // TILE)
            gy = int(cy // TILE)
            if world.get(gx, gy):
                return gx, gy
        return None

    def try_break(self, world, gx, gy):
        now = pygame.time.get_ticks()
        if now - self.last_hit_time < self.hit_cooldown:
            return

        block = world.get(gx, gy)
        if not block:
            return

        res = block.damage()
        self.last_hit_time = now

        if res:
            if res != "dirt":
                self.inv[res] += 1
            world.remove(gx, gy)

    def update(self, world):
        keys = pygame.key.get_pressed()
        in_air = self.y < GROUND_Y

        if in_air:
            if keys[pygame.K_LEFT]: self.vx -= 0.5
            if keys[pygame.K_RIGHT]: self.vx += 0.5
            self.vy += 0.5
            if keys[pygame.K_SPACE] and self.on_ground:
                self.vy = -10
        else:
            if keys[pygame.K_LEFT]: self.vx -= 1.2
            if keys[pygame.K_RIGHT]: self.vx += 1.2
            if keys[pygame.K_UP]: self.vy -= 1.2
            if keys[pygame.K_DOWN]: self.vy += 1.2

        self.vx *= 0.92
        self.vy *= 0.92

        self.vx = max(-MAX_SPEED, min(MAX_SPEED, self.vx))
        self.vy = max(-MAX_SPEED, min(MAX_SPEED, self.vy))

        self.on_ground = False

        self.x += self.vx
        hit = self.collide(world)
        if hit:
            gx, gy = hit
            self.try_break(world, gx, gy)
            self.x -= self.vx
            self.vx *= -0.6

        self.x = max(0, min(WIDTH - self.w, self.x))

        self.y += self.vy
        hit = self.collide(world)
        if hit:
            gx, gy = hit
            self.try_break(world, gx, gy)
            self.y -= self.vy

            if in_air:
                if self.vy > 0:
                    self.vy = 0
                    self.on_ground = True
                else:
                    self.vy *= -0.3
            else:
                self.vy *= -0.6

    def draw(self, cam_y):
        pygame.draw.rect(screen, COLORS["player"],
            (self.x, self.y - cam_y, self.w, self.h))

# ===== 상인 =====
class Merchant:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.w = 28
        self.h = 28

    def draw(self, cam_y):
        pygame.draw.rect(screen, (255,220,50),
            (self.x, self.y - cam_y, self.w, self.h))

# ===== UI =====
def draw_ui(player):
    x = 20
    y = 20
    size = 25
    gap = 10

    pygame.draw.rect(screen, (50,50,50), (10,10,140,120))

    for r in ["iron","copper","water"]:
        pygame.draw.rect(screen, COLORS[r], (x, y, size, size))
        pygame.draw.rect(screen, (255,255,255), (x, y, size, size), 2)

        txt = font_small.render(str(player.inv[r]), True, (255,255,255))
        screen.blit(txt, (x + size + 10, y))

        y += size + gap

# ===== 초기화 =====
world = World()
player = Player()

W = WIDTH // TILE
mid = W // 2

merchant = Merchant((mid-2)*TILE, TILE - 28)

camera_y = 0
font_big = pygame.font.SysFont(None, 80)
font_small = pygame.font.SysFont(None, 40)

state = "menu"
paused = False

# ===== 루프 =====
running = True
while running:
    clock.tick(60)

    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            running = False

        if e.type == pygame.KEYDOWN:
            if state == "menu" and e.key == pygame.K_SPACE:
                state = "game"

            elif state == "game":
                if e.key == pygame.K_ESCAPE:
                    if not paused:
                        paused = True
                    else:
                        pygame.quit()
                        sys.exit()

                elif paused and e.key == pygame.K_SPACE:
                    paused = False

    if state == "menu":
        screen.fill((0,0,0))

        title = font_big.render("DOME GAME", True, (255,255,255))
        start = font_small.render("Press SPACE to Start", True, (200,200,200))

        screen.blit(title, (WIDTH//2 - title.get_width()//2, HEIGHT//2 - 100))
        screen.blit(start, (WIDTH//2 - start.get_width()//2, HEIGHT//2))

        pygame.display.flip()
        continue

    screen.fill((135,206,235))

    if not paused:
        player.update(world)
        world.update_vision(player)

    camera_y = player.y - HEIGHT//2

    ground_screen_y = GROUND_Y - camera_y
    pygame.draw.rect(screen, (0,0,0),
        (0, ground_screen_y, WIDTH, HEIGHT - ground_screen_y))

    world.draw(camera_y)
    merchant.draw(camera_y)
    player.draw(camera_y)

    draw_ui(player)

    # ===== 일시정지 화면 =====
    if paused:
        overlay = pygame.Surface((WIDTH, HEIGHT))
        overlay.set_alpha(150)
        overlay.fill((0,0,0))
        screen.blit(overlay, (0,0))

        txt1 = font_big.render("PAUSED", True, (255,255,255))
        txt2 = font_small.render("SPACE: Resume", True, (200,200,200))
        txt3 = font_small.render("ESC: Quit", True, (200,200,200))

        screen.blit(txt1, (WIDTH//2 - txt1.get_width()//2, HEIGHT//2 - 100))
        screen.blit(txt2, (WIDTH//2 - txt2.get_width()//2, HEIGHT//2))
        screen.blit(txt3, (WIDTH//2 - txt3.get_width()//2, HEIGHT//2 + 50))

    pygame.display.flip()

pygame.quit()

